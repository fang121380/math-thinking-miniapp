# Contributing

## Development Requirements

- Node.js 18 or newer
- WeChat DevTools for Mini Program compilation and interaction checks

## Required Checks

```powershell
npm run prepare:upload
```

Do not commit `project.private.config.json`, a personal AppID, environment files, logs, or unreviewed external question data.

## Question Content Rules

- Project-authored questions must be distinct in wording, arithmetic structure, options, hints, and solution text.
- External questions require an explicit compatible license, source evidence, attribution, manual curriculum mapping, and audit approval.
- Do not copy questions from commercial exercise books, paid question banks, or full examination papers.

See [docs/question-source-admission.md](docs/question-source-admission.md) for the acceptance criteria.
