# Fan Math Mini Program Source Package

## Open in Codex

Open this `math-thinking-miniapp` folder as the workspace.

## Run Tests

```powershell
npm test
```

The project uses only the Node.js built-in test runner. No `node_modules` install is required for the included tests.

## Required Before Uploading

After any question-bank change, run this command before uploading in WeChat DevTools:

```powershell
npm run prepare:upload
```

It first enumerates and audits every published question, then runs the complete regression suite. A non-zero exit means the version is not approved for upload. The auditor lives in `scripts/audit-question-bank.js`; keep it outside `miniprogram/` so it is not included in the Mini Program package.

## Open in WeChat DevTools

Import this exact folder as the Mini Program project. The AppID and Mini Program root are already set in `project.config.json`.

## Important Paths

- `miniprogram/`: Mini Program source
- `miniprogram/utils/question-bank-edition-data.js`: edition and grade question generator
- `miniprogram/utils/textbook-edition-profiles.js`: 8 editions x 6 grades curriculum profiles
- `miniprogram/utils/background-music.js`: BGM loading logic
- `miniprogram/packages/junior/mission-engine.js`: junior thinking-task generator and validator
- `miniprogram/assets/audio/bgm/`: ten compact main-package BGM loops
- `tests/`: automated regression tests

## BGM Packaging

The ten compact licensed BGM loops live in the main package so `InnerAudioContext` can play them reliably on real devices. Junior-only task generation lives in the `packages/junior` subpackage to preserve main-package headroom. Keep the complete main package below the WeChat 2 MB limit; original full recordings are retained in `docs/source-audio/` and are not uploaded.
