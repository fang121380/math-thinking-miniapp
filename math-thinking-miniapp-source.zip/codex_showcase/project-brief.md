# Project Brief

- Product: 小思路，四年级数学思维微信小程序。
- Route: Native Mini Program.
- First preview: 摸底测试 -> 结果 -> 每日三题 -> 错题分析 -> 成长中心。
- Data: Local only.
- Textbook: 六年制人教版四年级数学。
- Out of scope: 登录、排行榜、广告、付费、社交、云服务、AI 聊天和正式发布。

