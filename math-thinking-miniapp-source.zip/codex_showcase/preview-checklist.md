# Preview Checklist

- [x] WeChat DevTools opened the intended `math-thinking-miniapp` project.
- [x] DevTools rendered the latest source without project-owned compile errors.
- [x] Cutout-phone safe area kept content below the status/capsule region.
- [x] `梵数学` branding and the colored transparent rabbit rendered.
- [x] Unfinished diagnostic resumed at question 2/8 with the same question.
- [x] Difficulty switched among simple, medium, and hard states.
- [x] Daily goal switched among 3, 5, and 10 and persisted across navigation.
- [x] A hard-mode daily question came from the hard eligible range.
- [x] The 10-question Home state showed `1/10` without layout overlap.
- [x] Grades 1-6 are selectable and render matching current-learning maps and isolated question pools.
- [x] Package size, JSON, JavaScript syntax, asset references, and secret scan passed.
- [x] All three game rows routed to their own complete interaction mode.
- [x] Number Puzzle rejected an illegal move, produced a legal hint, completed, generated a different next board, and resumed an unfinished board.
- [x] Pattern Detective handled no selection and a wrong option, completed a generated pattern, and generated a different next sequence.
- [x] Shape Partition handled an incomplete selection, accepted a connected equal split, and generated a different next layout.
- [x] Completed rounds awarded one star once and exposed only the next-round action.
- [x] Sound and reminder switches persisted; completed games loaded local audio without a project-owned error.
- [x] Home showed the once-daily open-app reminder when the daily task had not started.
- [x] Load, save, navigation, input, game validation, and audio failure paths expose child-facing feedback.
- [x] The 2026-07-21 automated run passed 136/136 tests; the Mini Program source measured 1,520,260 bytes (1,484.6 KiB).
- [x] User accepted the updated preview on 2026-07-15.

## 2026-07-21 question-bank review

- [x] The published bank records the 2022 national curriculum standard, eight textbook catalogues, and common structures from public real and mock papers as its reference basis.
- [x] Referenced papers are used only for knowledge coverage, question structures, error patterns, and difficulty ladders; prompts, values, choices, solutions, and mistake notes are rewritten locally.
- [x] The bank contains 10,928 practice questions and 3,648 diagnostic variants across eight textbook editions, grades 1-6, three difficulty levels, and choice/fill/problem types.
- [x] Every textbook-grade-difficulty-type pool has at least 24 questions covering eight knowledge points; published practice prompts and IDs are unique.
- [x] Fresh automated verification passed 136/136 tests on 2026-07-21.
- [x] DevTools displayed the selected grade-six diagnostic question correctly; `pages/test/test` reported 303-429 ms `Page.onLoad` during two runs.
- [ ] DevTools cold compile still reports an internal `WAServiceMainContext Error: timeout` after an 18-20 second launch. The stack contains only SDK runtime frames and no project file; this remains an IDE/runtime issue to recheck with a current stable DevTools/base-library pair.

DevTools: Stable v2.01.2510290

Simulator: cutout phone, runtime safe top 55 px

Known non-blocking tool messages: guest-mode `webapi_getwxaasyncsecinfo:fail`, `WAServiceMainContext` SDK timeout/internal frame timing, HarmonyOS API advisory, and Git path warning. None referenced project source files.

## 2026-08-04 child learning journey

- [x] Added local daily path choice: `复习一下` prioritizes due and weak knowledge; `挑战一下` keeps the selected difficulty and includes a thinking-pattern question where the selected pool supports one.
- [x] Added a guarded mistake-recovery route: analysis -> small-step question -> same-kind retry -> return to the saved daily or self-practice position. Recovery answers update local mastery but do not change daily completion, streak, or star rewards.
- [x] Audited recovery selection against all 10,928 practice questions: 10,900 questions (99.74%) have two safe same-topic recovery variants. The remaining 28 use the prior analysis and same-kind retry fallback because no second non-harder same-topic item exists.
- [x] Added four local learning-journey rows and weak-area game recommendation. Game rounds count as optional participation only and do not modify textbook mastery.
- [x] Automated suite: 168/168 passing on 2026-08-04.
- [x] Static syntax check: 39 JavaScript files parse and 11 WXML files have balanced tags.
- [x] Main package: 1,564,610 bytes (about 1.49 MiB), below the 1.75 MiB project limit.
- [x] DevTools CLI opened this exact project and started the existing local service on port 18782; no preview, upload, or publish command was run.
- [ ] Direct simulator interaction could not be recorded in this run because the desktop automation bridge twice rejected a refreshed WeChat DevTools window as stale. Recheck the visible routes manually in DevTools after its window bridge is stable: daily mode choice, wrong-answer recovery, growth journey, and recommended game.

## 2026-08-04 first-grade five-question diagnostic

- [x] A new local learner now selects grade 1-6 before starting; the default textbook is RJB and existing learners with progress are not reset or forced through the new selection.
- [x] Every diagnostic attempt now selects five concise entry questions with unique IDs and knowledge points, covering calculation, data, geometry, pattern, and problem solving plus choice/fill/problem types.
- [x] The entry bank has 1,440 original light variants across eight textbook editions, grades 1-6, and three difficulty levels. All 5,088 diagnostic and 10,928 practice prompts are unique.
- [x] Every entry question includes answer, choices where applicable, hint, solution, knowledge summary, mistake notes, source-pattern metadata, and a valid selected answer.
- [x] Automated suite: 171/171 passing on 2026-08-04.
- [x] Static checks: 40 JavaScript files parse and 11 WXML files have balanced tags.
- [x] Main package: 1,589,582 bytes (about 1.516 MiB), below the 1.75 MiB project limit.
- [x] DevTools CLI reopened this exact local project successfully; no preview, upload, or publish command was run.
- [ ] Direct simulator interaction was not captured because the desktop automation bridge twice rejected the active DevTools window with an internal stale-handle error. No project-owned compile error was reported by the CLI path.

## 2026-08-05 one-time grade confirmation

- [x] Existing local learners without grade-confirmation version 2 are redirected to select a current grade once, even if they already completed an earlier diagnostic.
- [x] Grade confirmation preserves stars, mistakes, completed and served question IDs, completion dates, daily completion totals, streaks, and local learning history.
- [x] Only unfinished grade-bound work is cleared: the old diagnostic, today\'s task, recovery task, and cached self-practice task. The newly selected grade then starts a fresh five-question diagnostic.
- [x] Home now redirects unconfirmed learners to the grade selector before loading a daily task, preventing restored pages from bypassing the confirmation.
- [x] Automated suite: 171/171 passing on 2026-08-05.

## 2026-08-05 learning retention foundation

- [x] Added a seven-day local math-theme rotation. The daily selector prefers one eligible theme-ability question without replacing due review, challenge reasoning, question-type coverage, grade, textbook, difficulty, or unseen-first safeguards.
- [x] Added a one-time bundled-content notice. It is dismissed locally per content-bank version and does not depend on a server or reset an active daily task.
- [x] Added a local recovery-win total. It increments only after the final same-kind recovery question is answered correctly; it does not change daily completion, stars, or the original mistake record.
- [x] Home and Growth expose the theme, update notice, and recovery progress with safe-area-compatible existing layouts.
- [x] Automated suite: 176/176 passing on 2026-08-05.
- [x] DevTools CLI reopened this exact local project and started the existing local service on port 18782. No preview, upload, publish, data-clear, or true-device command was run.
- [ ] Direct simulator interaction was not captured in this run. Confirm the visible theme band, dismiss the update notice once, and complete one recovery chain in DevTools before a release.

## 2026-08-08 junior-stage quality verification

- [x] The primary and junior stage selectors, stage-aware grades, textbook maps, five-question diagnostic flow, question-bank scope isolation, unit-aware answer checks, and junior games are covered by the current automated suite.
- [x] Full automated suite: 260/260 passing on 2026-08-08. This includes generated-question calculation audits, edition/grade/difficulty isolation, unit and equivalent-fraction checks, diagnostic rotation, game consistency fuzzing, saved-round recovery, audio/BGM contracts, and package checks.
- [x] `project.config.json` parses as UTF-8 JSON; all 11 declared page routes have their required JavaScript, WXML, WXSS, and page-config files.
- [x] Main package: 1,764,355 bytes (about 1.683 MiB), below the 2 MiB true-device limit.
- [x] The logged-in DevTools local service opened this exact project directory on 2026-08-08. The project-open segment contains no project-owned WXML, WXSS, JavaScript, or runtime error entry.
- [ ] A fresh simulator interaction recording was intentionally not taken in this pass because the user requested no desktop-window control. Before the next release, manually exercise: stage selection -> five-question diagnostic -> junior daily practice -> one junior game -> wrong-answer analysis.

## 2026-08-11 content and interaction integrity pass

- [x] Rebuilt the primary topic generators that had a calculation label but the wrong learning form: elapsed time, data comparison, averages, proportions, cone volume, money counting, and decimal tenths.
- [x] Corrected invalid content contracts: reverse reasoning never applies to estimates or remainders, estimate choices have one nearest result, fraction choices have one mathematically accepted option, rounded decimal division states its precision, and answer units are checked both with and without typed units.
- [x] Corrected exact-division labels and two-step word-problem quantities; the catalog now contains 5,088 diagnostic questions and 10,930 practice questions.
- [x] Bumped the bundled content version to `2026.08.11.1`, so a device receives a fresh daily set after this correction while retaining historical learning records.
- [x] Prevented direct/back-stack entry into the diagnostic before initial grade confirmation, locked duplicate grade taps during navigation, and raised the grade-button touch target to 104rpx with compliant muted-text contrast.
- [x] Corrected type-specific game hints for logic seating and shape matching. Exhausted game pools already mark returned rounds as review rounds and are covered by regression tests.
- [x] Full automated suite: 322/322 passing on 2026-08-11. This includes question-bank audits, units, stage isolation, game/mission fuzzing, audio contracts, storage, layout structure, and content-update behavior.
- [x] Static verification: 46 Mini Program JavaScript files parse; four required JSON files parse; all published questions pass the audit and all 6,043 choice questions have exactly one accepted option.
- [x] Main package: 1,820,347 bytes (about 1.74 MiB), leaving 276,805 bytes below the 2 MiB true-device cap.
- [x] WeChat DevTools CLI reopened this exact local project successfully on 2026-08-11. No preview, upload, or publish command was run.
- [ ] A final true-device/simulator interaction recording was not automated in this pass. Before the next release, manually exercise: first grade selection -> five-question diagnostic -> one daily question -> logic seating hint -> shape-hunt hint -> one junior mission.

## 2026-08-12 question-bank quality pass

- [x] Rewrote the junior generator's learner-facing stems: no internal condition labels, framework jargon, or generic "result" instructions remain. Geometry, functions, statistics, and trigonometry now state a complete mathematical task.
- [x] Replaced ordinal-driven junior values with bounded, age-appropriate parameter pools. Diagnostic and practice slots are isolated; geometry uses valid condition sets rather than arbitrary transformed answers.
- [x] Added edition-visible, topic-relevant context to junior questions and enforced cross-edition, cross-difficulty, and diagnostic/practice condition uniqueness.
- [x] Repaired primary numeric ranges, expanded genuine reverse-reasoning questions, and preserved all primary questions while making duplicate learner-visible activities distinct across editions and grades.
- [x] Full automated suite: 383/383 passing on 2026-08-12. This includes all answer-unit contracts, choice uniqueness, curriculum metadata, explanations, age ranges, game/mission interactions, storage, package structure, and audio contracts.
- [x] Full published-bank audit: 21,261 questions, 21,261 unique IDs, 0 curriculum/result/duplicate-quality issues with textbook isolation required.
- [x] Main package measured 1,823,772 bytes (about 1.739 MiB), leaving 273,380 bytes below the 2 MiB true-device cap; all 10 bundled BGM tracks remain present.
- [ ] The current WeChat DevTools window could be located but the desktop bridge could not bring its minimized/covered simulator forward. No project-owned compile error was observed through the local test path. Before a new upload, reopen the project and complete one simulator run: grade selection -> five-question diagnostic -> daily question -> a primary game -> a junior mission.
